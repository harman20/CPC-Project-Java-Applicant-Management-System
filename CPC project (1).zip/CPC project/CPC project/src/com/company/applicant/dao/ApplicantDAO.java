package com.company.applicant.dao;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.company.applicant.bean.ApplicantBean;
import com.company.applicant.util.DBUtil;

public class ApplicantDAO {
	public String addApplicant(ApplicantBean studentBean)
	{
			String status="";

			try{
				Connection connection = DBUtil.getConn();

				String query = "insert into APPLICANT_TBL values(?,?,?,?,?,?,?);";

				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1,studentBean.getApplicant_Id());
				preparedStatement.setString(2,studentBean.getApplicant_Name());
				preparedStatement.setInt(3,studentBean.getMarks1());
				preparedStatement.setInt(4,studentBean.getMarks2());
				preparedStatement.setInt(5,studentBean.getMarks3());
				preparedStatement.setString(6,studentBean.getApplicant_Result());
				preparedStatement.setString(7,studentBean.getApplicant_Grade());

				preparedStatement.executeQuery();
				status = "SUCCESS";

			}catch (Exception e){
				status = "FAIL";
				e.printStackTrace();
			}

			return status;
	}
	
	public ArrayList<ApplicantBean> getByResult(String criteria) throws SQLException, ClassNotFoundException {
		ArrayList<ApplicantBean> ar=new ArrayList<ApplicantBean>();
		Connection connection = DBUtil.getConn();
		String query;
		switch(criteria) {
			case "PASS":
			case "pass":
				query = "select * from APPLICANT_TBL where applicant_result='PASS'";
				break;
			case "FAIL":
			case "fail":
				query = "select * from APPLICANT_TBL where applicant_result='FAIL'";
				break;
			case "ALL":
			case "all":
				query = "select * from APPLICANT_TBL";
				break;
			default:
				return null;
		}

		ResultSet resultSet = connection.prepareStatement(query).executeQuery();

		while (resultSet.next()){
			ApplicantBean bean = new ApplicantBean();
			bean.setApplicant_Id(resultSet.getString(1));
			bean.setApplicant_Name(resultSet.getString(2));
			bean.setMarks1(resultSet.getInt(3));
			bean.setMarks2(resultSet.getInt(4));
			bean.setMarks3(resultSet.getInt(5));
			bean.setApplicant_Result(resultSet.getString(6));
			bean.setApplicant_Grade(resultSet.getString(7));

			ar.add(bean);

		}
	
		return ar;
	}
	public String generateApplicantId (String applicant_name) throws SQLException, ClassNotFoundException {
		Connection connection = DBUtil.getConn();

		String query = "select APPLICANT_SEQ.nextval from DUAL;";

		ResultSet resultSet = connection.prepareStatement(query).executeQuery();
		String id = applicant_name.substring(0,2).toUpperCase();
		if(resultSet.next()){
			String num = String.valueOf(resultSet.getInt(1));
			id+=num;
		}
		return id;
	}
}
