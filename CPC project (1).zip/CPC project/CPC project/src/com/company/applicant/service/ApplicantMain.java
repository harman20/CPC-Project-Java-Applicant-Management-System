package com.company.applicant.service;

import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

import com.company.applicant.dao.ApplicantDAO;
import com.company.applicant.util.DBUtil;
import com.company.applicant.util.WrongDataException;
import com.company.applicant.bean.ApplicantBean;


public class ApplicantMain {

	public String addApplicant(ApplicantBean studBean) {

		String result = "";
		ApplicantDAO applicantDAO = new ApplicantDAO();

		try{

			if(studBean ==null || studBean.getApplicant_Name().equals("") ||
					studBean.getApplicant_Name().length() <2 || (0>studBean.getMarks1() || studBean.getMarks1()>100)
					|| (0>studBean.getMarks2() || studBean.getMarks2()>100) ||
						(0>studBean.getMarks3() || studBean.getMarks3()>100)){
				throw new WrongDataException();
			}

			String id = applicantDAO.generateApplicantId(studBean.getApplicant_Name());
			studBean.setApplicant_Id(id);

			int marks = studBean.getMarks1() + studBean.getMarks2() + studBean.getMarks3();
			String applicant_result,grade;
			if(marks>=240){
				applicant_result = "PASS";
				grade="Distinction";
			}else if(marks>=180){
				applicant_result = "PASS";
				grade = "First Class";
			}else if(marks>=150){
				applicant_result = "PASS";
				grade = "Second Class";
			}else if(marks>=105){
				applicant_result = "PASS";
				grade = "Third Class";
			}else{
				applicant_result = "FAIL";
				grade = null;
			}

			studBean.setApplicant_Result(applicant_result);
			studBean.setApplicant_Grade(grade);

			String progress = applicantDAO.addApplicant(studBean);

			if(progress.equalsIgnoreCase("SUCCESS")){
				result = id+":"+studBean.getApplicant_Result();
			}else{
				result = "Error";
			}

		}catch (WrongDataException e){
			result = "Incorrect Data";
			System.out.println(e.toString());
		} catch (SQLException | ClassNotFoundException throwables) {
			throwables.printStackTrace();
		}
		return result;

	}
	public ArrayList<ApplicantBean> displayAll(String criteria) throws SQLException, ClassNotFoundException {
		ApplicantDAO applicantDAO = new ApplicantDAO();
		return applicantDAO.getByResult(criteria);
	}
	
	public static void main(String[] args) {

		ApplicantMain applicantMain = new ApplicantMain();


	}

}
